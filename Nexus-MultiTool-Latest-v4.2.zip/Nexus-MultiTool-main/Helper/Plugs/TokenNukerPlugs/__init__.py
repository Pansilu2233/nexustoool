__title__ = 'Nexus'
__author__ = 'Vatos'
__copyright__ = 'discord.gg/nexustools'
__version__ = '1.0.0'

from Helper.Plugs.TokenNukerPlugs.Common.utils import *
from Helper.Plugs.TokenNukerPlugs.Funcs.Mass_dm import massDM
from Helper.Plugs.TokenNukerPlugs.Funcs.Leave_server import leaveServer
from Helper.Plugs.TokenNukerPlugs.Funcs.delete_server import deleteServers
from Helper.Plugs.TokenNukerPlugs.Funcs.delete_friends import deleteFriends
from Helper.Plugs.TokenNukerPlugs.Funcs.Fuck_account import fuckAccount
from Helper.Plugs.TokenNukerPlugs.Funcs.close_dms import close_all_dms
from Helper.Plugs.TokenNukerPlugs.Funcs.Nuke_account import Nuke_account
from Helper.Plugs.TokenNukerPlugs.Funcs.block_friends import blockAllFriends
